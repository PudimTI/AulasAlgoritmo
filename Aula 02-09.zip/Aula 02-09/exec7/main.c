#include <stdio.h>
#include <string.h>
int main() {
    char palavra[51];
    printf("Digite uma palavra: \n");
    gets(palavra);
    fflush(stdin);
    printf("Digite a letra da palavra orignal que sera trocada: \n");
    char letra = (char)getchar();
    fflush(stdin);
    printf("Digite a letra que substitura a letra original: \n");
    char outra = (char)getchar();

    for(int i = 0; i < strlen(palavra);++i){
        if(palavra[i] == letra){
            palavra[i] = outra;
        }
    }
    printf("\n%s",palavra);
    return 0;
}
