#include <stdio.h>
#include <string.h>

int main() {
    char palavra[21], chrP;
    char caracter;

    printf("Digite uma palavra: ");
    gets(palavra);
    fflush(stdin);
    printf("Digite um caracter: ");
    caracter = getchar();


    return 0;
}
