#include <stdio.h>

//Exemplo do uso do empilhamento para realizar funções entre as mudanças de pilha da recursitivdade

void up(int n){
    if (n <= 0) return;
    up(n-1); //A função empilha a proxima pilha antes de imprimir, tornando os prints em ordem decrescente
    printf("%d ", n);
}

void down(int n){
    if (n <= 0) return;
    printf("%d ", n);
    down(n-1); //A função empilha a proxima pilha depois de imprimir, tornando os prints em ordem crescente
}
int main() {
    up(10);
    down(10);
    return 0;
}
