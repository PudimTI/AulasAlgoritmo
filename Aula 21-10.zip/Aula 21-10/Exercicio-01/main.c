#include <stdio.h>
#define T 10

void ler(int v[]);
void imprimir(int *p_v);

int main() {
    int vetor[T];
    ler(vetor);
    imprimir(vetor);
    return 0;
}

void ler(int v[]){
    printf("Digite os dados \n");
    for (int i = 0; i < T; ++i) {
        printf("Digite o dado %d \n", i+1);
        scanf("%d", &v[i]);
    }
}

void imprimir(int *p_v){
    printf("Imprimindo os dados do vetor \n");
    for (int i = 0; i < T; ++i) {
        printf("Elemento [%d] = [%d] \n", i, *(p_v + i));
    }
}