//
// Created by joao.pedro on 05/03/2024.
//

#include <stdio.h>

#include "pilha.h"

double pl_valores[TAMANHO];
char pl_operadores[TAMANHO];
int pl_va_posicao;
int pl_op_posicao;


// Funções

bool VAestaVazia()
{
    return pl_va_posicao == 0;
}

bool OPestaVazia()
{
    return pl_op_posicao == 0;
}

bool va_push(double valor){
    pl_valores[pl_va_posicao] = valor;
    pl_va_posicao++;

    return true;
}

bool va_pop(int *valor){
    if(VAestaVazia())
    {
        return false;
    }
    pl_va_posicao--;
    *valor = pl_valores[pl_va_posicao];
    return true;
}

bool op_push(int valor){
    pl_operadores[pl_op_posicao] = valor;
    pl_op_posicao++;

    return true;
}

bool op_pop(int *valor){
    if(OPestaVazia())
    {
        return false;
    }
    pl_op_posicao--;
    *valor = pl_operadores[pl_op_posicao];
    return true;
}

double va_topo(){
    return pl_valores[pl_va_posicao];
}

char op_topo(){
    return pl_operadores[pl_op_posicao];
}

