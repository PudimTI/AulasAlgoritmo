#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#define T 7

int main() {
    srand(time(NULL));
    int m[T][T] = {0};

    for (int i = 0; i < T; ++i) {
        for (int j = i; j < T; ++j) {
        // para diagnal inferior => for (int j = 0; j <= i; ++j)
            m[i][j] = (rand() % 9) + 1;
        }
    }

    for (int i = 0; i < T; ++i) {
        for (int j = 0; j < T; ++j) {
            printf("[%1d] ", m[i][j]);
        }
        printf("\n");
    }

    return 0;
}
