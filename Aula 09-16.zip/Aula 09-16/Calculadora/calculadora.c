#include <stdio.h>
#include "operacoes.h"
/**
 * Função de entrada da calculadora
 * Solicita dois valores, a operação e devolve o resultado
 * @return
 */

int main() {
    int x, y, result, opcao = 0;

    printf("Calculadora - Dois valores\n");
    printf("Entre com o primeiro valor: \n");
    scanf("%d", &x);
    printf("Entre com o segundo valor: \n");
    scanf("%d", &y);

    do {


        printf("Menu da Calculadora \n");
        printf("1. Somar \n");
        printf("2. Subtrair \n");
        printf("3. Multiplicar \n");
        printf("4. Dividir \n");
        printf("9. Sair \n");

        printf("Digite sua opcao: \n");
        scanf("%d", &opcao);
        switch (opcao) {
            case 1:
                printf("Soma: %d \n", somar(x, y));
                break;
            case 2:
                printf("Subtracao: %d \n", subtrair(x, y));
                break;
            case 3:
                printf("Multiplicacao: %d \n", multiplicar(x, y));
                break;
            case 4:
                result = dividir(x, y);
                result == -1 ? printf("Valor invalido \n") : printf("Divisao: %d \n", result);
                break;
            case 9:
                printf("Encerrando... \n");
                break;
            default:
                printf("Operacao invalida \n");
                break;
        }
    } while (opcao!=9);
    return 0;
}
