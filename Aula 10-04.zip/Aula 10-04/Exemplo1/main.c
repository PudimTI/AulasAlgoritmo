#include <stdio.h>

int main() {
    int x = 10;
    int y = 20;
    printf("%d \n", x);
    printf("%d \n", y);
    printf("Endereco de x: %d \n", &x);
    printf("Endereco de y: %d \n", &y);
    int * p_x = &x;
    int * p_y = &y;
    printf("Endereco de x: %d \n", p_x);
    printf("Endereco de y: %d \n", p_y);
    printf("Conteudo de x: %d \n", *p_x);
    printf("Conteudo de y: %d \n", *p_y);
    return 0;
}
