//
// Created by joao.pedro on 05/03/2024.
//

#include <stdio.h>

#include "pilha.h"

double pl_valores[TAMANHO];
char pl_operadores[TAMANHO];
int pl_va_posicao;
int pl_op_posicao;

// Funções

bool push(int valor){
}

bool pop(int *valor){

}

void pl_imprime(){

}