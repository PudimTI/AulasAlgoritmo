#include <stdio.h>

int main() {
    char nome[41];
    printf("Digite seu nome: \n");
    gets(nome);
    printf("seu nome: %s \n", nome);

    for (int i = 0; i < 41; ++i) {
        if (nome[i]=='\0') break;
        printf("%c\n", nome[i]);
    }
    return 0;
}
