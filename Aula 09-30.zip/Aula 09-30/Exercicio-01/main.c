#include <stdio.h>

//NAO TERMINADO
int potencia(int x, int y){
    if (y == 0) return 1;
    return x = potencia();
}

int main() {
    printf("Hello, World!\n");
    return 0;
}
