//
// Created by joao.pedro on 05/03/2024.
//

#ifndef PROJETO_PILHA_PILHA_H
#define PROJETO_PILHA_PILHA_H

#include <stdbool.h>

// Constantes
enum {
    TAMANHO = 10,
};

// Variáveis
extern double pl_valores[TAMANHO];
extern char pl_operadores[TAMANHO];
extern int pl_va_posicao;
extern int pl_op_posicao;

// Protótipos
bool push(int valor);
bool pop(int *valor);

#endif //PROJETO_PILHA_PILHA_H
