#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int magico;
    int palpite;
    int cont=0;
    srand(time(NULL));
    magico = rand() %1000;

    while (1) {
        cont++;

        printf("Digite seu palpite %d: ", cont);
        scanf("%d", &palpite);

        if(palpite == magico){
            printf("Parabens voce venceu!\n");
            return 0;
        }else {
            if (cont == 10){
                printf("Suas chances terminaram!");
                return 0;
            }
            palpite < magico ? printf("Palpite Baixo\n") : printf("Palpite alto\n"); //if ternario
            //o '?' pode ser lido com Então; e : pode ser lido como se não

        }

    }
    return 0;
}
