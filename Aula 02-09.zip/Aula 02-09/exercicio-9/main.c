#include <stdio.h>

int main() {
    int matriz1[3][3], matriz2[3][3], matrizSoma[3][3];

    printf("Matriz 1\n");
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            printf("Digite o valor de [%d][%d]: ", i, j);
            scanf("%d", &matriz1[i][j]);
        }
    }
    printf("\nMatriz 2\n");
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            printf("Digite o valor de [%d][%d]", i, j);
            scanf("%d", &matriz2[i][j]);
        }
    }

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            printf("[%d] ", matriz1[i][j]);
        }
        printf("\n");
    }
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            printf("[%d] ", matriz2[i][j]);
        }
        printf("\n");
    }

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            matrizSoma[i][j] = matriz1[i][j] + matriz2[i][j];
            printf("[%d] ", matrizSoma[i][j]);
        }
        printf("\n");
    }
    return 0;
}
