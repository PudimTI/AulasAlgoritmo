#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    srand(time(NULL));
    int vetor[10] = {0};
    int gerado = 0;
    int cont = 0;

    do {
        gerado = (rand() % 100) + 1;
        vetor[cont++] = gerado;
    } while (gerado % 5 != 0 && cont < 10);
    for (int i = 0; i < cont; ++i) {
        printf("[%3d] ", vetor[i]);
    }
    return 0;
}
