#include <stdio.h>
#include <string.h>
int main() {
   char str[42],strreve[42];
    printf("Digite uma palavra: ");
    gets(str);
    fflush(stdin);
    strcpy(strreve,str);
    strrev(strreve);

    if(strcmp(str,strreve)==0){
        printf("Eh um palindromo");
    }else{
        printf("Nao eh um palindromo");
    }
}
