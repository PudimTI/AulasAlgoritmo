#include <stdio.h>
#include <string.h>

int main() {
    char frase[] = "maricas mirtens alok";
    char *p = strchr(frase, ' a');
    printf("%d \n", p);

    puts(p);

    puts(strrev(frase));
    return 0;
}
