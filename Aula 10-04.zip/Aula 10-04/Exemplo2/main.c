#include <stdio.h>

void trocar(int *p_a, int *p_b);

int main() {
    int pri = 15;
    int seg = 30;
    trocar(&pri, &seg);
    printf("Pri: %d, Seg: %d \n", pri,seg);

    return 0;
}

void trocar(int *p_a, int *p_b){
    int aux = *p_a;
    *p_a = *p_b;
    *p_b = aux;
}
