#include <stdio.h>

int main() {
    int v[20] = {0}; //zerar vetor
    for (int i = 0; i < 20; i++) {
        printf("Pos[%2d] = Valor [%d] \n", i, v[i]);
    }
    return 0;
}
