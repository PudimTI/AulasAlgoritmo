#include <stdio.h>

void imp_invertido(char * p_s);
int main() {
    char nome[51];
    gets(nome);
    imp_invertido(nome);
    return 0;
}

void imp_invertido(char * p_s){
    char * p_texto = p_s;
    while (*p_texto != '\0'){
        p_texto++;
    }
    while (p_texto > p_s){
        p_texto--;
        putchar(*p_texto);
    }
}