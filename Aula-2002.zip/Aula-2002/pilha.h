//
// Created by aluno on 20/02/2024.
//

#ifndef AULA_2002_PILHA_H
#define AULA_2002_PILHA_H
#include <stdbool.h>

// Constantes
enum { //Gera "apelidos" para coisas
    TAMANHO = 5,
};

// Variaveis
extern int pl_pilha[TAMANHO]; //variaveis criadas aqui precisam ter "extern" para passar no main
extern int pl_posicao;

// Protótipos
bool push(int valor);
bool pop(int *valor);
bool estaCheia();
bool estaVazia();
void imprimir();

#endif //AULA_2002_PILHA_H
