/**
* Lista de exercícios de função
*/

/**
 * Função que retorne 1 se for positivo e -1 se o valor seja negativo e 0 se for ZERO
 * @param valor O valor a ser comparado
 * @return 
 */
int verPositividade(int valor);