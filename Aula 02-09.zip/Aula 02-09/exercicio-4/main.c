#include <stdio.h>
#include <string.h>

int main() {
    char str[10], str_vet[50]={'\0'};
    int contador;

    for (int i = 0; i < 5; ++i) {
        fflush(stdin);
        printf("Digite uma palavra: ");
        gets(str);
        fflush(stdin);

        strcat(str_vet, str);
    }

    contador = (int)strlen(str_vet);

    printf("A palavra %s possui comprimento de %d", str_vet, contador);
    return 0;
}
