#include <stdio.h>

void imprimir(char *p_s);


int main() {
    imprimir("maricas");
    return 0;
}

void imprimir(char *p_s){

    while (*p_s != '\0'){
        printf("%d \n", p_s);
        putchar(*p_s++);
    }
}