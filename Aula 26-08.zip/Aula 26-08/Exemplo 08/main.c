#include <stdio.h>
#include <string.h>
int main() {
    char palavra[41];
    char outra[41];

    printf("Digite uma palavra: \n");
    gets(palavra);
    fflush(stdin);
    printf("Digite outra palavra: \n");
    gets(outra);
    printf("%d\n", strcmp(palavra, outra));

    if(strcmp(palavra, outra) == 0){
        printf("Palavras iguais \n");
    }else{
        if(strcmp(palavra, outra) > 0){
            printf("Primeira palavra alfabeticamente maior \n");
        }else{
            printf("Esta em ordem alfabetica\n");
        }
    }
    printf("Tamanho em caracteres da palavra");

    return 0;
}
