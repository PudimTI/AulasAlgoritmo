#include <stdio.h>

int main() {
    int vet1[5], vet2[5], soma=0;
    for(int i = 0; i < 5; i++){
        printf("\nDigite um valor para o 1 vetor na posicao %d:  ",i);
        scanf("%d",&vet1[i]);
    }
    for(int i = 0; i < 5; i++){
        printf("\nDigite um valor para o 2 vetor na posicao %d:  ",i);
        scanf("%d",&vet2[i]);
    }
    for(int i = 0; i < 5; i++){
        soma+=vet1[i]*vet2[i];

    }

    printf("\nproduto escalar: %d",soma);
    return 0;
}
