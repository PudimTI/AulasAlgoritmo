#include <stdio.h>

int countChar (char *p_palavra, char letra);

int main() {
    printf("%d \n", countChar("balls?!?!?!?!?!?!?!?!?", 'l'));
    return 0;
}

int countChar (char *p_palavra, char letra){
    int tot = 0;
    while(*p_palavra != '\0'){
        if(*p_palavra == letra) tot++;
        p_palavra++;
    }
    return tot;
}