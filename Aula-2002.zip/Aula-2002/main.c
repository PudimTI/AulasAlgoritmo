#include <stdio.h>


#include "pilha.h"

// Constantes
enum {
    OP_NAO_SELECIONADA = 0,
    OP_PUSH,
    OP_POP,
    OP_IMPRIMIR,
    OP_SAIR
};

// Variaveis
int numero;

// Protótipos
int menu();

int main() {
    int opcao = OP_NAO_SELECIONADA;

    while (opcao != OP_SAIR){
        opcao = menu();
        switch (opcao) {
            case OP_POP:
                if (pop(&numero)){
                    printf("Saiu %d da pl_pilha\n", numero);
                } else{
                    printf("Pilha vazia!\n");
                }
                break;
            case OP_PUSH:
                printf("Digite um numero: ");
                scanf("%d",&numero);

                if(!push(numero)){ //Se push retornar VERDADEIRO ele não entra no if.
                    printf("Estouro de pl_pilha!\n");
                }
                break;
            case OP_IMPRIMIR:

                imprimir();
                break;
            case OP_SAIR:
                break;
        }
    }
    return 0;
}

int menu(){
    printf("Menu\n");
    printf("%d - Push\n", OP_PUSH);
    printf("%d - Pop\n", OP_POP);
    printf("%d - Imprimir\n", OP_IMPRIMIR);
    printf("%d - Sair\n", OP_SAIR);
    printf("Digite uma opção: ");
}