#include <stdio.h>

void ler(int *p, int t);
void imprimir(int *p, int t);

int main() {
    int vetor[10];
    ler(vetor, 10);
    imprimir(vetor, 10);
    return 0;
}

void ler(int *p, int t){
    for (int i = 0; i < t; ++i) {
        printf("Digite um dado: \n");
        scanf("%d", p++);
    }
}

void imprimir(int *p, int t){
    for (int i = 0; i < t; ++i) {
        printf("%d \n", *p);
        p++;
    }
}
