#include <stdio.h>
#include <string.h>

void compor(char *p_s1, char *p_s2);

char * compor2(char *p_s1, char *p_s2);

void imprimir(char *str);

int main() {
    char p1[30];
    char p2[30];

    fflush(stdin);
    printf("Digite a primeira palavra\n");
    gets(p1);
    fflush(stdin);
    printf("Digite a segunda palavra\n");
    gets(p2);

    //printf("%s %s", p1, p2);

    //compor(p1,p2);
    char * p_str = compor2(p1, p2);
    imprimir(p_str);
    return 0;
}

void imprimir(char *p_str) {
    while (*p_str != '\0'){
        putchar(*p_str);
        p_str++;
    }
    return;
}

char * compor2(char *p_s1, char *p_s2) {
    char final[60];
    int tot = 0;

    while (*p_s1 != '\0'){
        final[tot++] = *p_s1++;
    }
    final[tot++] = ' ';
    while (*p_s2 != '\0'){
        final[tot++] = *p_s2++;
    }

    return (char *)final;
}

void compor(char *p_s1, char *p_s2) {

    while (*p_s1 != '\0'){
        putchar(*p_s1++);
    }
    while (*p_s2 != '\0'){
        putchar(*p_s2++);
    }
}
