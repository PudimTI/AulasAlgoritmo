#include <stdio.h>

int main() {
    char vogais[5] = "aeiou";
    printf("%s \n", vogais);


    return 0;
}
