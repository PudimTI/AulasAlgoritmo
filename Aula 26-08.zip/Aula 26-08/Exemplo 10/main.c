#include <stdio.h>
#include <string.h>

int main() {
    char palavra[21];
    char outra[21];
    gets(palavra);
    fflush(stdin);
    

    return 0;
}
