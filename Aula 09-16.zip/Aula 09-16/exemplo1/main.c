#include <stdio.h>

double imc(double peso, double altura);

int main() {
    double p, a;
    printf("Calculo do IMC \n");
    printf("Digite o seu peso: \n");
    scanf("%lf", &p);
    printf("Digite a sua altura: \n");
    scanf("%lf", &a);
    printf("O seu IMC e: %lf", imc(p,a));



    return 0;
}

double imc(double peso, double altura){
    return peso / (altura * altura);
}
