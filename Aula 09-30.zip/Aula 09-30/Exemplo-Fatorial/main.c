#include <stdio.h>

//Metodo Classico
int fatorial(int n){
    int f = 1;
    for (int i = 1; i <= n; ++i) {
        f*= i;
    }
    return f;
}
//Recursivo
int fatorialR(int n){
    if(n == 1) return 1;
    return n * fatorialR(n - 1);
}

int main() {
    int n;
    printf("Fatorial de: \n");
    scanf("%d", &n);
    printf("O fatorial e: %d \n", fatorial(n));
    printf("O fatorial recursivo e: %d \n", fatorialR(n));
    return 0;
}
