#include <stdio.h>
#include <string.h>

int main() {
    char nome[21];
    char sobrenome[21];

    printf("Entre com o nome: \n");
    gets(nome);
    fflush(stdin);
    printf("Entre com o sobrenome: \n");
    gets(sobrenome);
    char nome_completo[41] = {'\n'};
    strcat(nome_completo, nome);
    strcat(nome_completo, " ");
    strcat(nome_completo, sobrenome);

    printf("Nome completo: %s \n", nome_completo);
    char copia[42] = {'\n'};
    strcpy(copia, nome_completo);
    printf("Copia: %s \n", copia);
    return 0;
}
