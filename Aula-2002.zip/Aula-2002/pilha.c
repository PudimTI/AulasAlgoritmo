//
// Created by aluno on 20/02/2024.
//
#include <stdio.h>

#include "pilha.h"
int pl_pilha[TAMANHO];
int pl_posicao;

// Funções
bool push(int valor){
    if (estaCheia()){
        return false;
    }

    pl_pilha[pl_posicao] = valor;
    pl_posicao++;

    return true;
}

bool pop(int *valor){
    if(estaVazia()){
        return false;
    }

    pl_posicao--; //Segundo o algoritmo do Pop, ele volta uma posição e tira o valor da pl_pilha
    *valor = pl_pilha[pl_posicao];
    return true;
}

bool estaCheia(){
    return pl_posicao == TAMANHO;
}

bool estaVazia(){
    return pl_posicao == 0;
}

void imprimir(){
    for (int i = (pl_posicao - 1); i >= 0; i--) {
        printf("| %d |\n", pl_pilha[i]);
    }
    if (pl_posicao > 0){
        printf("+---+\n");
    }

}