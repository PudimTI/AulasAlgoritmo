#include <stdio.h>

int main() {
    int a, b;

    printf("Digite um valor: \n");
    scanf("%d", &a);

    printf("Digite um valor: \n");
    scanf("%d", &b);

    int x;
    if (b){ //entra no if caso não seja 0
        x = a / b;
        printf("Resultado: %d\n", x);
    }else{
        printf("Não é possivel dividir por 0");
    }
    return 0;
}
