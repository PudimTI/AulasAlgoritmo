#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    srand(time(NULL));
    //gerar 10 numeros aleatorios
    int sorteio[10] = {0};
    //logica para gerar os valores
    for (int i = 0; i < 10; ++i) {
        sorteio[i] = (rand() % 100) + 1;
    }
    //imprimir valor
    for (int i = 0; i < 10; ++i) {
        printf("%3d ", sorteio[i]);
    }
    printf("\n");
    return 0;
}
