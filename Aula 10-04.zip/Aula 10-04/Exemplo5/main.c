#include <stdio.h>
int strl(char * str);
int main() {
    int t = strl("boboca");
    printf("Tam: %d \n", t);
    return 0;
}

int strl(char * str){
    char * p = str; //ponteiro para deslocamento
    while (*p != '\0') p++;
    return p - str;
}
