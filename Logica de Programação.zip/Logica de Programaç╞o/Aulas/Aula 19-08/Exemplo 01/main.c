#include <stdio.h>

int main() {
    char letra;

    printf("Digite uma letra: ");
    letra = getchar();
    fflush(stdin);

    char letra2;
    printf("Digite outra letra: ");
    letra2 = getchar();

    printf("Letras digitdas %c e %c \n", letra, letra2);
    printf("%c\n", letra2);

    return 0;
}
