/**
* Módulo de operações matematicas, criado em 16/09
 * Exemplo de Aula de Funções
*/

/**
 * Função que executa a soma de dois valores inteiros
 * @param a Primeiro valor inteiro
 * @param b Segundo valor inteiro
 * @return A soma do primeiro com o segundo valor
 */
int somar(int a, int b);

/**
 * Função que executa a subtração de dois valores inteiros
 * @param a Primeiro valor inteiro
 * @param b Segundo valor inteiro
 * @return A subtração do primeiro com o segundo valor
 */
int subtrair(int a, int b);

/**
 * Função que executa a multiplicação de dois valores inteiros
 * @param a Primeiro valor inteiro
 * @param b Segundo valor inteiro
 * @return A multiplicação do primeiro com o segundo valor
 */
int multiplicar(int a, int b);

/**
 * Função que executa a divisão de dois valores inteiros
 * @param a Primeiro valor inteiro
 * @param b Segundo valor inteiro
 * @return A divisão do primeiro com o segundo valor
 */
int dividir(int a, int b);