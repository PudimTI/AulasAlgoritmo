#include <stdio.h>
#include <string.h>
int main() {
    char str1[42], str2[42], str3[42]="";
    printf("Digite a 1 palavra: \n");
    gets(str1);
    fflush(stdin);
    printf("Digite a 2 palavra: \n");
    gets(str2);
    strcat(str3,str1);
    strcat(str3,str2);
    if(strcmp(str1,str2) == 0){
        printf("As duas palavras sao iguais");
    }else{
        printf("As duas palavras sao diferentes");
    }
    printf("\n%s",str3);
}
